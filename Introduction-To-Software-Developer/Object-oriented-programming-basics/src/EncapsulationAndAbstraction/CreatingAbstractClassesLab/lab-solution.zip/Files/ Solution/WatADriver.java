/** TODO 12 Solution to: Make this class "WatADriver" a child class of
 *           the "Robot" class
 *           is given by using "extends Robot" after "public class WatADriver" below.
 */
public class WatADriver extends Robot{

    /** TODO 17: Implement the abstract methods methods setChoice and takeAction
     *           of the parent class "Robot"
     */
    @Override
    public void setChoice() {
        /** TODO 18:  Inside the method "setChoice" display
         *            "Inside choice setting of WatADriver” and
         *            inside "takeAction" display “WatADriver will
         *            drive or fly here”
         */

        System.out.println("Inside choice setting of WatADriver");

        /** TODO 18 Solution End **/
    }

    @Override
    public void takeAction() {
        /** TODO 18:  Inside the method "setChoice" display
         *            "Inside choice setting of WatADriver” and
         *            inside "takeAction" display “WatADriver will
         *            drive or fly here”
         */


        System.out.println("WatADriver will drive or fly here");

        /** TODO 18 Solution End **/
    }


    /** TODO 17 Solution End **/
}

