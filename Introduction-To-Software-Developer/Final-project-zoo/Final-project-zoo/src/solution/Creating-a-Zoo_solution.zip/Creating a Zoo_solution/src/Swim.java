/** TODO 6 is Solution implemented by creating this interface "Swim"
 *         and declaration of the method "swimming".
 *         The todo states:
 *                          create a new interface named "Swim"
 *                          and declaring a method inside it
 *                          named "swimming" with the return type
 *                          "void"
 **/
public interface Swim {
    public void swimming();
}
/** TODO 6 is Solution End **/